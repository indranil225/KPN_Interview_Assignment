import { LightningElement, api, wire } from 'lwc';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getOrderItems from '@salesforce/apex/OrderController.getOrderItems';
import confirmOrder from '@salesforce/apex/OrderController.confirmOrder';
import getOrderDetails from '@salesforce/apex/OrderController.getOrderDetails';

const columns = [
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'List Price', fieldName: 'ListPrice', type: 'text'},
    { label: 'Quantity', fieldName: 'Quantity', type: 'text'},
    { label: 'Total Price', fieldName: 'TotalPrice', type: 'text'},
]

export default class OrderItemList extends LightningElement {
    @api recordid;
    showTable = false;
    orderItemList = [];
    orderItemTempList = [];
    columns = columns;
    error;
    isDisabled = false;

    page = 1; 
    items = []; 
    dataItems = []; 
    startingRecord = 1;
    endingRecord = 0; 
    pageSize = 5; 
    totalRecountCount = 0;
    totalPage = 0;

    wiredResult;

    @api
    reloadComp(){
        refreshApex(this.wiredResult); //refresh order items list
    }
 
    @wire(getOrderItems,{recId:'$recordid'})// get order items
    wiredRecords(result) {
        if (result.data) {
            this.wiredResult = result;
            this.orderItemTempList = result.data;
            let orderItemRecArray = [];
            this.orderItemTempList.forEach(orderItemRec => {
                let orderItemRecRow = {};
                orderItemRecRow.Id = orderItemRec.Id;
                orderItemRecRow.Name = orderItemRec.Product2.Name;
                orderItemRecRow.ListPrice = orderItemRec.UnitPrice;
                orderItemRecRow.Quantity = orderItemRec.Quantity;
                orderItemRecRow.TotalPrice = orderItemRec.TotalPrice;

                orderItemRecArray.push(orderItemRecRow);
            });
            this.orderItemList = orderItemRecArray;
            this.showTable = true;

            this.items = this.orderItemList;
            this.totalRecountCount = this.orderItemList.length; 
            this.totalPage = Math.ceil(this.totalRecountCount / this.pageSize); 
            
            this.dataItems = this.items.slice(0,this.pageSize); 
            this.endingRecord = this.pageSize;
            this.columns = columns;

            this.error = undefined;
        } else if (result.error) {
            this.error = result.error;
        }
    }

    @wire(getOrderDetails,{recId:'$recordid'})// get order details
     orderDetails(result) {
        if (result.data) {
            if(result.data.Status === 'Activated'){
                this.isDisabled = true;
            }
            else{
                this.isDisabled = false;
            }
        } 
    }
    
    /*
      confirm order handler
    */
    confirmOrder(){
        confirmOrder({recId: this.recordid})
        .then(result => {
            if(result && result === 'Success'){
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Order confirmed! ',
                        variant: 'success'
                    })
                )
                window.location.reload();
            }
            else{
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: 'Unable to confirm order!',
                        variant: 'error'
                    })
                )
            }
        })
        .catch(error => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Unable to confirm order!',
                    variant: 'error'
                })
            )
            
        });
    }

    //previous button handler
    previousHandler() {
        if (this.page > 1) {
            this.page = this.page - 1; //decrease page by 1
            this.displayRecordPerPage(this.page);
        }
    }

    //next button handler
    nextHandler() {
        if((this.page<this.totalPage) && this.page !== this.totalPage){
            this.page = this.page + 1; //increase page by 1
            this.displayRecordPerPage(this.page);            
        }             
    }

    //display records per page
    displayRecordPerPage(page){

        this.startingRecord = ((page -1) * this.pageSize) ;
        this.endingRecord = (this.pageSize * page);

        this.endingRecord = (this.endingRecord > this.totalRecountCount) 
                            ? this.totalRecountCount : this.endingRecord; 

        this.dataItems = this.items.slice(this.startingRecord, this.endingRecord);

        this.startingRecord = this.startingRecord + 1;
    } 

}