import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getAvailableProductList from '@salesforce/apex/OrderController.getAvailableProductList';
import addOrderItem from '@salesforce/apex/OrderController.addOrderItem';

const columns = [
    { label: 'Action', type: "button", typeAttributes: {  
        label: 'Add to Order',  
        name: 'Add',  
        title: 'Add',  
        disabled: { fieldName: 'isActive'},  
        value: 'Add',  
        iconPosition: 'left', 
    }},
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'List Price', fieldName: 'ListPrice', type: 'text'},
]

export default class AvailableProductList extends LightningElement {
    @api recordid;
    showTable = false;
    productList = [];
    columns = columns;
    error;

    page = 1; 
    items = []; 
    dataItems = []; 
    startingRecord = 1;
    endingRecord = 0; 
    pageSize = 5; 
    totalRecountCount = 0;
    totalPage = 0;
    
    connectedCallback() {
		this.loadRecords();//get available product list
	}
	loadRecords() {
		getAvailableProductList({recId: this.recordid})
			.then(result => {
                if(result !== undefined && result.length > 0){
                    let productRecArray = [];
                    result.forEach(productRec => {
                        let productRecRow = {};
                        productRecRow.Id = productRec.productId;
                        productRecRow.Name = productRec.productName;
                        productRecRow.ListPrice = productRec.unitPrice;
                        productRecRow.PriceBookEntryId = productRec.Id;
                        productRecRow.isActive = productRec.isActive;

                        productRecArray.push(productRecRow);
                    });
                    this.productList = productRecArray;
                    this.showTable = true;

                    this.items = this.productList;
                    this.totalRecountCount = this.productList.length; 
                    this.totalPage = Math.ceil(this.totalRecountCount / this.pageSize); 
                    
                    this.dataItems = this.items.slice(0,this.pageSize); 
                    this.endingRecord = this.pageSize;
                    this.columns = columns;

                    this.error = undefined;
                }
			})
			.catch(error => {
                this.showTable = false;
                this.error = error;
                console.log('Error in Response===>>>>>>>>>'+error);
			});
    }

    callRowAction( event ) {   //add order item   
        const productId =  event.detail.row.Id;  
        const quantity =  '1';
        const orderId = this.recordid;
        const unitPrice = event.detail.row.ListPrice;
        const pricebookEntryId = event.detail.row.PriceBookEntryId;
        addOrderItem({orderId: orderId, productId: productId, quantity: quantity, unitPrice: unitPrice, pricebookEntryId: pricebookEntryId})
            .then(result => {
                this.dispatchEvent(new CustomEvent('productadd')); //custom event to refresh order items list
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Product added!',
                        variant: 'success'
                    })
                );
            })
        .catch(error => {
            this.error = error;
            console.log('Error in Response===>>>>>>>>>'+error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Unable to add product!',
                    variant: 'error'
                })
            );
        });
    }

    //previous button handler
    previousHandler() {
        if (this.page > 1) {
            this.page = this.page - 1; //decrease page by 1
            this.displayRecordPerPage(this.page);
        }
    }

    //next button handler
    nextHandler() {
        if((this.page<this.totalPage) && this.page !== this.totalPage){
            this.page = this.page + 1; //increase page by 1
            this.displayRecordPerPage(this.page);            
        }             
    }

    //display record per page
    displayRecordPerPage(page){

        this.startingRecord = ((page -1) * this.pageSize) ;
        this.endingRecord = (this.pageSize * page);

        this.endingRecord = (this.endingRecord > this.totalRecountCount) 
                            ? this.totalRecountCount : this.endingRecord; 

        this.dataItems = this.items.slice(this.startingRecord, this.endingRecord);

        this.startingRecord = this.startingRecord + 1;
    }    
    
}