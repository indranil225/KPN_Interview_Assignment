declare module "@salesforce/apex/CampingListController.getItems" {
  export default function getItems(): Promise<any>;
}
declare module "@salesforce/apex/CampingListController.saveItem" {
  export default function saveItem(param: {item: any}): Promise<any>;
}
