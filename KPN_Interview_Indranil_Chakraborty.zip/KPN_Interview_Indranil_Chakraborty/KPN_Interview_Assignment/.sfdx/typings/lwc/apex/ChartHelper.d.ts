declare module "@salesforce/apex/ChartHelper.GetInventory" {
  export default function GetInventory(): Promise<any>;
}
