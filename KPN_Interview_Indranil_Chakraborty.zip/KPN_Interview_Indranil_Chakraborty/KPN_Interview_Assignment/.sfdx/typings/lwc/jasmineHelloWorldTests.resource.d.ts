declare module "@salesforce/resourceUrl/jasmineHelloWorldTests" {
    var jasmineHelloWorldTests: string;
    export default jasmineHelloWorldTests;
}