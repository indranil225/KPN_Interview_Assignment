declare module "@salesforce/resourceUrl/jasmineExampleTests" {
    var jasmineExampleTests: string;
    export default jasmineExampleTests;
}