declare module "@salesforce/resourceUrl/lts_sinon" {
    var lts_sinon: string;
    export default lts_sinon;
}