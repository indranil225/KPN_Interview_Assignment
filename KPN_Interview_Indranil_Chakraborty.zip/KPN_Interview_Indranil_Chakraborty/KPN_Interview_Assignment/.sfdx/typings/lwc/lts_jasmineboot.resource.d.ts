declare module "@salesforce/resourceUrl/lts_jasmineboot" {
    var lts_jasmineboot: string;
    export default lts_jasmineboot;
}