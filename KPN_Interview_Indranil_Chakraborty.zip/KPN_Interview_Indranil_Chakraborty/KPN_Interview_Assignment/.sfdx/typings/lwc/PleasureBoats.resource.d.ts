declare module "@salesforce/resourceUrl/PleasureBoats" {
    var PleasureBoats: string;
    export default PleasureBoats;
}