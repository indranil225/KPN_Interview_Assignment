declare module "@salesforce/resourceUrl/jasmineLightningDataServiceTests" {
    var jasmineLightningDataServiceTests: string;
    export default jasmineLightningDataServiceTests;
}