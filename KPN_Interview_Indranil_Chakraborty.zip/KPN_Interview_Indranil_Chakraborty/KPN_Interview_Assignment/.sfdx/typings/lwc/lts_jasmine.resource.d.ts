declare module "@salesforce/resourceUrl/lts_jasmine" {
    var lts_jasmine: string;
    export default lts_jasmine;
}