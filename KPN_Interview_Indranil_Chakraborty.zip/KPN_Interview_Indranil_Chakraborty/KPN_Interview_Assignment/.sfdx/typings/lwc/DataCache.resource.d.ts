declare module "@salesforce/resourceUrl/DataCache" {
    var DataCache: string;
    export default DataCache;
}